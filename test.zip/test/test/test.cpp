#include <SFML/Graphics.hpp>
#include <time.h>
#include<iostream>
#include <vector>
#include "Maze.h"
#include<fstream>
#include "StateSpaceTree.h"
#define N 10
using namespace sf;
using namespace std;
void draw_text(bool i_black, unsigned short i_x, unsigned short i_y, const std::string& i_text, sf::RenderWindow& i_window)
{
    short character_x = i_x;
    short character_y = i_y;
    unsigned char character_width;
    sf::Sprite character_sprite;
    sf::Texture font_texture;
    font_texture.loadFromFile("images/Font.png");
    character_width = font_texture.getSize().x / 96;
    character_sprite.setTexture(font_texture);
    if (1 == i_black)
    {
        character_sprite.setColor(sf::Color(0, 0, 0));
    }
    for (const char a : i_text)
    {
        if ('\n' == a)
        {
            character_x = i_x;
            character_y += font_texture.getSize().y;
            continue;
        }
        character_sprite.setPosition(character_x, character_y);
        character_sprite.setTextureRect(sf::IntRect(character_width * (a - 32), 0, character_width, font_texture.getSize().y));
        character_x += character_width;
        i_window.draw(character_sprite);
    }
}
void solver(int grid3[10][10],int sgrid[12][12],int*start,int*end,string file) {
    
    /*int length = 0;
    bool hasPath = false;*/

    Maze maze(start, end);
    
    //vector<vector<int>> grid3 = {};
   /* maze.findPath(grid4);*/
    maze.read(file);
    maze.findPath();
   
  
    for (int i = 1; i <= 10; i++)
        for (int j = 1; j <= 10; j++)
        {
            grid3[i - 1][j - 1] = 0;
        }

    for (int i = 1; i <= 10; i++)
        for (int j = 1; j <= 10; j++)
        {
            sgrid[i][j] = (maze.matrix)[j - 1][i - 1];
        }


}
class player {
private:
    Texture t;
    int playeri, playerj;
    Sprite myPlayer;
public:
    player(int x, int y) {
        playeri = x;
        playerj = y;
        t.loadFromFile("C:\\Users\\a\source\\repos\\test\\test\\image\\Rat-removebg-previeww.png");
        myPlayer.setTexture(t);
        myPlayer.setPosition(playerj * 100, playeri * 100);
        myPlayer.scale(0.2, 0.2);
    }
};
int main()
{
    bool running = true;
    int start[] = { 0, 0 };
    int end[] = { N - 1, N - 1 };
    int w = 32;
    int grid[12][12];
    int sgrid[12][12];
    int grid3[N][N];
    string file ="";
    player p1(0, 0);
    solver(grid3, sgrid,start,end,file);

    Texture t;
    t.loadFromFile("C:\\Users\\a\\source\\repos\\test\\test\\image\\blackandwhite.jpeg");
    Sprite s(t);
    Texture t2;
    t2.loadFromFile("C:\\Users\\a\\source\\repos\\test\\test\\image\\blackandblue.jpeg");
    Sprite s2(t2);
   RenderWindow app(VideoMode(400, 400), "Rat in Maze");

    while (app.isOpen())
    {

        Vector2i pos = Mouse::getPosition(app);
        int x = pos.x / w;
        int y = pos.y / w;
        
        Event e;
        while (app.pollEvent(e))
        {
            switch (e.type) {
            case Event::KeyPressed:
                switch (e.key.code)
                {
                case Keyboard::Enter:



                    running = false;

                    break;

                }
                

                switch (e.key.code) {
                case Keyboard::Num1:
                    running = false;
                    int num = 3;
                    start[0] = { N - num };
                    start[1] = { N - num };
                    end[0] = { N - 1 };
                    end[1] = { N - 1 };
                    file = "C:\\Users\\a\\source\\repos\\test\\test\\easy.txt";
                    solver(grid3, sgrid, start, end,file);
                    running = true;

                    break;
                } switch (e.key.code) {
                case Keyboard::Num2:
                    running = false;
                    int num = 10;
                    start[0] = { N - num };
                    start[1] = { N - num };
                    end[0] = { N - 1 };
                    end[1] = { N - 1 };
                    file = "C:\\Users\\a\\source\\repos\\test\\test\\maze.txt";
                    solver(grid3, sgrid, start, end, file);
                    running = true;
                    break;
                }

                break;
            }
            if (e.type == Event::Closed)
                    app.close();
        }
        if (running)
        {
            app.clear(Color::White);

            for (int i = 1; i <= 10; i++)
                for (int j = 1; j <= 10; j++)
                {
                    if (sgrid[i][j] == 1||sgrid[i][j]==0) {
                     
                    s.setTextureRect(IntRect(sgrid[i][j] * w, 0, w, w));
                    s.setPosition(i * w, j * w);
                    app.draw(s);
                    }
                    else {
                        if (sgrid[i][j] == 5) {
                            player p1(x, y);
                            sf::RenderWindow(p1);
                            

                        }
                        s.setTextureRect(IntRect(sgrid[i][j] * w, 0, w, w));
                        s.setPosition(i * w, j * w);
                        app.draw(s);
                    }
                   
                    
                }
        }


        else
        {
          
            
         app.clear(Color::White); 
            ifstream inFile("C:\\Users\\a\\source\\repos\\test\\test\\display.txt");

           
            
            for (int i = 1; i <= 10; i++)
                for (int j = 1; j <= 10; j++)
                {
                    inFile >> grid[j][i];

                }

            inFile.close();


            app.clear(Color::White);
          
            for (int i = 1; i <= 10; i++)
                for (int j = 1; j <= 10; j++)
                {

                    s2.setTextureRect(IntRect(grid[i][j] * w, 0, w, w));
                    s2.setPosition(i * w, j * w);
                    app.draw(s2);
                }
            
        }
        
        app.display();
    }
    return 0;
}
