//#include <SFML/Graphics.hpp>
//#include <time.h>
//#include "Maze.h"
//using namespace sf;
//using namespace std;
//#define N 10
//void draw_text(bool i_black, unsigned short i_x, unsigned short i_y, const std::string& i_text, sf::RenderWindow& i_window)
//{
//    short character_x = i_x;
//    short character_y = i_y;
//    unsigned char character_width;
//    sf::Sprite character_sprite;
//    sf::Texture font_texture;
//    font_texture.loadFromFile("images/Font.png");
//    character_width = font_texture.getSize().x / 96;
//    character_sprite.setTexture(font_texture);
//    if (1 == i_black)
//    {
//        character_sprite.setColor(sf::Color(0, 0, 0));
//    }
//    for (const char a : i_text)
//    {
//        if ('\n' == a)
//        {
//            character_x = i_x;
//            character_y += font_texture.getSize().y;
//            continue;
//        }
//        character_sprite.setPosition(character_x, character_y);
//        character_sprite.setTextureRect(sf::IntRect(character_width * (a - 32), 0, character_width, font_texture.getSize().y));
//        character_x += character_width;
//        i_window.draw(character_sprite);
//    }
//}
////int main()
////{
////    bool running = true;
////    int start[] = { 0, 0 };
////    int end[] = { N - 1, N - 1 };
////    Maze maze(start, end);
////    maze.findPath();
////    int w = 32;
////    int grid[12][12];
////    int sgrid[12][12];
////    int grid3[10][10];
////    maze.readfromfile(grid3);//
////    Texture t;
////    t.loadFromFile("images/blackandwhite.jpg");
////    Sprite s(t);
////    Texture t2;
////    t2.loadFromFile("images/blackandblue.jpg");
////    Sprite s2(t2);
////    srand(time(0));
////    RenderWindow app(VideoMode(400, 400), "Rat in Maze");
////    for (int i = 1; i <= 10; i++)
////        for (int j = 1; j <= 10; j++)
////        {
////            sgrid[i][j] = maze.matrix[j - 1][i - 1];
////            grid[i][j] = grid3[j - 1][i - 1];
////        }
////    while (app.isOpen())
////    {
////        Event e;
////        while (app.pollEvent(e))
////        {
////            switch (e.type) {
////            case Event::KeyPressed:
////                switch (e.key.code)
////                {
////                case Keyboard::Enter:
////                    running = false;
////                    break;
////                }
////                break;
////            }
////            if (e.type == Event::Closed)
////                app.close();
////        }
////        if (running)
////        {
////            app.clear(Color::White);
////
////            for (int i = 1; i <= 10; i++)
////                for (int j = 1; j <= 10; j++)
////                {
////                    s.setTextureRect(IntRect(sgrid[i][j] * w, 0, w, w));
////                    s.setPosition(i * w, j * w);
////                    app.draw(s);
////                }
////        }
////        else
////        {
////            app.clear(Color::White);
////            for (int i = 1; i <= 10; i++)
////                for (int j = 1; j <= 10; j++)
////                {
////                    s2.setTextureRect(IntRect(grid[i][j] * w, 0, w, w));
////                    s2.setPosition(i * w, j * w);
////                    app.draw(s2);
////                }
////        }
////        app.display();
////    }
////    return 0;
////}
//#include "Maze.h"
//#include "StateSpaceTree.h"
//#include<fstream>;
//using namespace std;
//
//
//Maze::Maze(int start[], int end[]) {
//    this->start = start;
//    this->end = end;
//}
//
////Function to initiate search process
//void Maze::findPath() {
//    visit(start[0], start[1]);
//    //cout << "Tree \n";
//    //stateSpaceTree.display(stateSpaceTree.root);
//    //stateSpaceTree.display_tree(stateSpaceTree.root);
//}
////Function to visit a cell and recursively make next move
//void Maze::visit(int x, int y) {
//    //Base Condition - Reached the destination cell
//    if (x == end[0] && y == end[1]) {
//        visited[x][y] = 1;
//        //Update hasPath to True (Maze has a possible path)
//        hasPath = true;
//        //Store the minimum of the path length
//        displaypath();
//        // printPath(current_path);
//        // howa da hena kdea bykhle el destination zero wla el ablha ??
//        return;
//    }
//    //Mark the current cell as visited
//    visited[x][y] = 1;
//    if (canVisit(x + 1, y)) {
//        visit(x + 1, y);
//    }
//
//    //2.Down
//    if (canVisit(x, y + 1)) {
//        visit(x, y + 1);
//    }
//
//    //3.Left
//    if (canVisit(x - 1, y)) {
//        visit(x - 1, y);
//    }
//
//    //4.Up
//    if (canVisit(x, y - 1)) {
//        visit(x, y - 1);
//    }
//}
//
////Function checks if (x,y) is a vaid cell or not
//bool Maze::canVisit(int x, int y) {
//    //Number of Columns in Maze
//    int m = sizeof(matrix[0]) / sizeof(matrix[0][0]);
//    //Number of rows in Maze
//    int n = sizeof(matrix) / sizeof(matrix[0]);
//    //Check Boundaries
//    if (x < 0 || y < 0 || x >= m || y >= n)
//        return false;
//    //Check 0 or already visited
//    if (matrix[x][y] == 0 || visited[x][y] == 1)
//        return false;
//    return true;
//}
//
//void Maze::printPath(vector<vector<int>> v)
//{
//    cout << "Path length: " << length << endl;
//    for (int i = 0; i < v.size(); i++)
//    {
//        cout << "(" << v[i][0] << "," << v[i][1] << ") ";
//    }
//    cout << endl << endl;
//}
//
//void Maze::displaypath()
//{
//    fstream output;
//    output.open(filename, std::ios_base::out);
//    for (int i = 0; i < N; i++)
//    {
//        for (int j = 0; j < N; j++)
//        {
//            output << visited[i][j] << " ";
//        }
//        output << endl;
//    }
//    output.close();
//    return;
//}
//void Maze::readfromfile(int myarray[N][N]) {
//    ifstream inputfile(filename);
//    for (int r = 0; r < N; r++)
//    {
//        for (int c = 0; c < N; c++)
//        {
//            inputfile >> myarray[r][c];
//        }
//    }
//}