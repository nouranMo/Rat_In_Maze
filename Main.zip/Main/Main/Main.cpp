#include <iostream>
#include "Maze.h"
#define N 7
int main()
{
	int start[] = { 0, 0 };
	int end[] = { N - 1, N - 1 };

	Maze maze(start, end);
	maze.read();
	maze.findPath();
	
}

